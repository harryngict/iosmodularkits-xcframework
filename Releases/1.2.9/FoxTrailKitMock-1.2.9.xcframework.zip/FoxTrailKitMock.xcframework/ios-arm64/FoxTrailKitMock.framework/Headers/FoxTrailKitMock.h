// FoxTrailKitMock - Auto-generated umbrella header
// Built for XCFramework distribution
